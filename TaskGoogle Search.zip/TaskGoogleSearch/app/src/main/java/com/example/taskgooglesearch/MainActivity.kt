package com.example.taskgooglesearch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.taskgooglesearch.data.data_surce.GoogleSearchApi
import com.example.taskgooglesearch.data.data_surce.GoogleSearchRetrofitService
import com.example.taskgooglesearch.domain.models.SearchModel
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    @OptIn(DelicateCoroutinesApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val call = GoogleSearchRetrofitService.retrofit.create(GoogleSearchApi::class.java)
        GlobalScope.launch(Dispatchers.Main) {
            call.getGoogleSearchModel("elon musk",20).enqueue(object : Callback<SearchModel> {
                override fun onResponse(call: Call<SearchModel>, response: Response<SearchModel>) {
                    for (result in response.body()!!.searchResults) {
                        Log.e("TAG", result.title)
                    }
                }

                override fun onFailure(call: Call<SearchModel>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "onFailure", Toast.LENGTH_SHORT).show()
                }

            }


            )
        }
    }
}