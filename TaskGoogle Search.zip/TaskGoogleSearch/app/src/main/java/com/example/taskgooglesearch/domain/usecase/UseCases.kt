package com.example.taskgooglesearch.domain.usecase

data class UseCases(
    val getSearchListUseCase: GetSearchListUseCase
)