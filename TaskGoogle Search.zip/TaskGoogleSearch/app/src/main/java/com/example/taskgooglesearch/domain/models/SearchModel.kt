package com.example.taskgooglesearch.domain.models

import com.google.gson.annotations.SerializedName


data class SearchModel(
    //some fields are commented
   /* val answers: List<String>,
    val device_region: String,
    val device_type: String,
    val image_results: List<Any>,
    val total: Int,
    val ts: Double,*/
    @SerializedName("results")
    var searchResults: List<SearchResult>
)