package com.example.taskgooglesearch.domain.models

data class Cite(
    val domain: String,
    val span: String
)