package com.example.taskgooglesearch.domain.models

data class AdditionalLink(
    val href: String,
    val text: String
)