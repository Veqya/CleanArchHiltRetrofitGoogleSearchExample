package com.example.taskgooglesearch.data.model

import com.example.taskgooglesearch.domain.models.SearchResult

data class SearchModelData(
    var searchResults: List<SearchResult>
)
