package com.example.taskgooglesearch.data.model

data class SearchResultData (
    var title: String="",
    var link: String="",
    var description: String=""
)